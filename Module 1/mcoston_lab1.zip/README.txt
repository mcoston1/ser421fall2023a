Full disclosure, I have had some of the worst 2 weeks recently. 
When this class started, I had an active COVID-19 infection. That was followed by having to work 15 hour days for the next week, making me absolutely incapable of doing classwork on the weekend. Then Monday and Tuesday of this week also being 15 hour days due to both of my jobs sucking majorly. 

Atop this mountain of life garbage, I have ADHD & Autism & PMDD & chronic migraines. It has been the perfect storm of badness. 


TLDR: Apologies for the garbage code. It's been a rough start to the school year. 