SER421 Module 2 Lab

Nothing too crazy here. I haven't yet implemented the very last requirement for Activity 3, as I'm mulling over the implementation. I might get it finished and turned in by this evening, I might not. We shall see. 


Nothing too crazy going on here. It functions as the instructions... instructed. 

There's a default case/response for unknown keys. 

There is a cute response for the key 'pod' (as in, Open the pod bay doors Hal). 


- Miranda