package com.example.restlab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestlabApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestlabApplication.class, args);
	}

}
