package com.example.restlab.modelhelpers;

public class SurveyInstanceRequest {
    
}
