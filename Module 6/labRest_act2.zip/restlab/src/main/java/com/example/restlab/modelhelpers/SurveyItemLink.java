package com.example.restlab.modelhelpers;

import java.util.List;

import com.example.restlab.model.SurveyItem;

public class SurveyItemLink {

    public static Object convertToLinks(List<SurveyItem> surveyItems) {
        return null;
    }
    
}
