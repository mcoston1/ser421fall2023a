package com.example.restlab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestlabApplicationTests {

	@Test
	void contextLoads() {
	}

}
